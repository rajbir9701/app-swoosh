//
//  ViewController.swift
//  app-swoosh
//
//  Created by Rajbir Kaur on 2020-05-04.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var swoosh: UIImageView!
    
    @IBOutlet weak var bgimg: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
 
    }
    @IBAction func unwindFromSkillVC(unwindSegue : UIStoryboardSegue){
        
    }

}

