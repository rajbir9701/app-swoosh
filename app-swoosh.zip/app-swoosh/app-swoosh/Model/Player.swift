//
//  Player.swift
//  app-swoosh
//
//  Created by Rajbir Kaur on 2020-05-06.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import Foundation
struct Player{
    var desiredLeague : String! 
    var selectedSkillLevel : String!
}
